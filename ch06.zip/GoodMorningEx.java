package ch06;

import java.util.Calendar;

public class GoodMorningEx {
	public static void main(String[] args) {
		Calendar now = Calendar.getInstance(); // Calendar 객체 생성
		
		// now는 현재 시간 값을 가지고 있음
				
		int year = now.get(Calendar.YEAR);
		int month = now.get(Calendar.MONTH);
		int day = now.get(Calendar.DAY_OF_MONTH);
		int dow = now.get(Calendar.DAY_OF_WEEK);
		
		System.out.println("현재 날짜는 " + year + "년 " + month + "월 " +
		day + "일입니다.");
		
		if(dow == 1) 
			System.out.println("요일은 일요일입니다.");
		else if(dow == 2) 
			System.out.println("요일은 월요일입니다.");
		else if(dow == 3) 
			System.out.println("요일은 화요일입니다.");
		else if(dow == 4) 
			System.out.println("요일은 수요일입니다.");
		else if(dow == 5) 
			System.out.println("요일은 목요일입니다.");
		else if(dow == 6) 
			System.out.println("요일은 금요일입니다.");
		else
			System.out.println("요일은 토요일입니다.");		
		
	}
}
