package ch05;

public class BlackWhiteTV extends TV {
	private int nColors;
	public BlackWhiteTV(int size, int nColors) {
		super(size);
		this.nColors = nColors;
	}
	
	public void printProperty() {
		System.out.println(getSize() + "인치 " + nColors + "흑백");
	}
	
	public static void main(String [] args) {
		BlackWhiteTV myTV = new BlackWhiteTV(50, 800);
		myTV.printProperty();
	}


}
