package ch05;

class Person {
	private char name;
	private char personNumber;
	public void name(char name) { this.name = name; }
	public void personNumber(char personNumber) { this.personNumber = personNumber; }
	public char getpersonNumber() { return personNumber; }
	public char name() { return name; }
}

public class Male extends Person {
	private String name;
	private String personNumber;
	
	public Male(String name, char personNumber) {
		super();
	}
}
