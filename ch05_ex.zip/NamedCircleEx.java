package ch05;

public class NamedCircleEx extends Circle {
	private String name;
	NamedCircleEx(int radius, String name) {
		super(radius);
		this.name = name;
	}
	public void show() {
		System.out.println(name + ", 반지름 = " + getRadius());
	}
	public static void main(String[] args) {
		NamedCircleEx w = new NamedCircleEx(5, "Waffle"); // NamedCircle(int r, String n) 생성자 작성
		NamedCircleEx c = new NamedCircleEx(10, "Cicle");
		w.show(); // NamedCircle에 show()를 작성
		c.show();
	}

}
