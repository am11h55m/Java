package ch04;

import java.util.Scanner;

public class Phone {
	private String name, tel, add;
	public Phone(String name, String tel, String add) { 
		this.name = name; 
		this.tel = tel;
		this.add = add;
	}
	public String getName() { return name; }
	public String getTel() { return tel; }
	public String getAdd() { return add; }

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("이름과 전화번호 입력 >>");
		String name = scanner.next();
		String tel = scanner.next();
		String add = scanner.next();
		Phone a = new Phone(name, tel, add);
		
		System.out.print("이름과 전화번호 입력 >>");
		name = scanner.next();
		tel = scanner.next();
		add = scanner.next();
		Phone b = new Phone(name, tel, add);
		
		System.out.println(a.getName() + "의 번호 " + a.getTel());
		System.out.println(a.getName() + "의 주소 " + a.getAdd());
		System.out.println(b.getName() + "의 번호 " + b.getTel());
		System.out.println(b.getName() + "의 주소 " + b.getAdd());
		
//		scanner.close();
	}

}
