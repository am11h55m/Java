package ch07;

import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class VectorBigEx {
	
	public static void printSmall(Vector<Integer> v) {  // 벡터 v의 정수 중 가장 큰 수 출력
		int big = v.get(0); // 맨 처음에 있는 수를 제일 큰 수로 초기화
		int small = v.get(0);
		for(int i=1; i<v.size(); i++) {
			if(small > v.get(i))
				small = v.get(i);
		}
		for(int j=1; j<v.size(); j++){
			System.out.print("벡터의 내용은 [" + v.get(j) + "]");
			}
		
		System.out.println("가장 작은 수는 " + small);		
	}
	
	public static void main(String[] args) {
		Vector<Integer> v = new Vector<Integer>();
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("정수(-1이 입력될 때까지)>> ");
		while(true) {
			int n = scanner.nextInt();
			if(n == -1) // 입력된 수가 -1이면
				break;
			v.add(n);
		}
		
		if(v.size() == 0) {
			System.out.print("수가 하나도 없음");
//			scanner.close();
			return;
		}
		
		printSmall(v); // 벡터 v의 정수 중 가장 큰 수 출력
//		scanner.close();
		
		System.out.print("삭제하고자 하는 수는 >> ");
		while(true) {
			int del = scanner.nextInt();

			for(int i=1; i<v.size(); i++) {
				if(del == v.get(i)) {
					v.remove(i);
					Collections.sort(v);
					for(int j=1; j<v.size(); j++){
						System.out.print("오름차순 벡터의 내용은 [" + v.get(j) + "]");
						}
				}
				else 
					System.out.println(del + " 은 벡터에 존재하지 않습니다.");
					Collections.sort(v);
					for(int j=1; j<v.size(); j++){
						System.out.print("오름차순 벡터의 내용은 [" + v.get(j) + "]");
						}
			}
			
		}
	}

}
