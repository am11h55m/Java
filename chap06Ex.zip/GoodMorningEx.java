package ch06;

import java.util.Calendar;

public class GoodMorningEx {

	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
	    int year = cal.get(Calendar.YEAR);
	    int month = cal.get(Calendar.MONTH) + 1; // get()은 0~30까지의 정수 리턴.
	    int day = cal.get(Calendar.DAY_OF_MONTH);
	    int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);

	    System.out.println("현재 날짜는 " + year + "년 " + month + "월 " + day + "일입니다.");
	    System.out.print("요일은 ");
	    switch(dayOfWeek) {
		    case Calendar.SUNDAY : System.out.print("일요일"); break;
		    case Calendar.MONDAY : System.out.print("월요일"); break; 
		    case Calendar.TUESDAY : System.out.print("화요일"); break;
		    case Calendar.WEDNESDAY : System.out.print("수요일"); break;
		    case Calendar.THURSDAY : System.out.print("목요일"); break;
		    case Calendar.FRIDAY: System.out.print("금요일"); break;
		    case Calendar.SATURDAY : System.out.print("토요일"); break;
	    }
	    System.out.println("입니다.");
	}

}