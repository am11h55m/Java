package ch04;


public class TVEx {
	private String manufacturer;
	private int year;
	private int size;
		
	public TVEx(String manufacturer, int year, int size) {
		this.manufacturer = manufacturer;
		this.year = year;		
		this.size = size;
	}
	
	public TVEx(String manufacturer, int year) {
		this.manufacturer = manufacturer;
		this.year = year;		
	}
	
	public void show() {
		System.out.print(this.manufacturer + "에서 만든 ");
		System.out.print(this.year + "년형 ");
		System.out.println(this.size + "인치 TV");
	}
	
	public void showPrint() {
		System.out.print(this.manufacturer + "에서 만든 ");
		System.out.print(this.year + "년형 ");
	}
	
	public static void main(String [] args) {
		TVEx myTVEx = new TVEx("LG", 2017, 32); // LG에서 만든 2017년 65인치
		myTVEx.show();
		TVEx yourTVEx = new TVEx("Samsung", 2022);
		yourTVEx.showPrint();
	}
}