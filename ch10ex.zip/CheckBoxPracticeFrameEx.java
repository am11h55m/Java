package PracticeNo04;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CheckBoxPracticeFrame extends JFrame {
    private JButton btn = new JButton("test button");
    private JLabel label = new JLabel("");

    public CheckBoxPracticeFrame() {
        super("CheckBox Practice Frame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        // ButtonGroup group = new ButtonGroup();
        // 해당 요구사항에서는 ButtonGroup을 사용하면 안 됨. (사용 시 RadioButton 체크 해제 불가능)

        JRadioButton Rb1 = new JRadioButton("버튼 비활성화");
        JRadioButton Rb2 = new JRadioButton("버튼 감추기");
        /*
        group.add(Rb1);
        group.add(Rb2);
        */
        c.add(Rb1);
        c.add(Rb2);
        c.add(btn);
        c.add(label);

        Rb1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED) {
                    btn.setEnabled(false);
                    label.setText("버튼 비활성화");
                }
                else {
                    btn.setEnabled(true);
                    label.setText("버튼 활성화");
                }
            }
        });
        Rb2.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED) {
                    btn.setVisible(false);
                    label.setText("버튼 감추기");
                }
                else {
                    btn.setVisible(true);
                    label.setText("버튼 보이기");
                }
            }
        });
        setSize(250,150);
        setVisible(true);
    }
    public static void main(String[] args) {
        new CheckBoxPracticeFrame();
    }
}
