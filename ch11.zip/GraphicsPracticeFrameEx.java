package ch11;

import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GraphicsPracticeFrameEx extends JFrame {
	public GraphicsPracticeFrameEx(){
		super("그래픽  다각형 연습");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setContentPane(new MyPanel());
		setSize(300,300);
		setVisible(true);
	}
	
	class MyPanel extends JPanel {
		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			int [] x = new int [4];
			int [] y = new int [4];
			x[0] = getWidth();
			y[0] = 0;
			x[1] = x[0];
			y[1] = getHeight();
			x[2] = 0;
			y[2] = y[1];
			x[3] = x[2];
			y[3] = y[0];
			
			for(int i=0; i<5; i++) {
				g.drawPolygon(x, y, 4);
				y[0] = y[0] + 10;
				x[0] = x[0] - 10;
				x[1] = x[1] - 10;
				y[1] = y[1] - 10;
				x[2] = x[2] + 10;
				y[2] = y[2] - 10;
				x[3] = x[3] + 10;
				y[3] = y[3] + 10;
			}
		}
	}
	
	
	static public void main(String[] args) {
		new GraphicsPracticeFrameEx();
	}
}
