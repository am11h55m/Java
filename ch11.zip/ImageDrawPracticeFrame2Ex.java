package ch11;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ImageDrawPracticeFrame2Ex extends JFrame {
	public ImageDrawPracticeFrame2Ex(){
		super("이미지 그리기 연습");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setContentPane(new MyPanel());
		setSize(400,400);
		setVisible(true);
	}
	
	class MyPanel extends JPanel {
		private ImageIcon icon = new ImageIcon("images/back.jpg");
		private Image img = icon.getImage();
		private JButton button1 = new JButton("Hide");
		private JButton button2 = new JButton("Show");
		private boolean showFlag = true;
		
		public MyPanel() {
			setLayout(new FlowLayout());
			add(button1); add(button2);
			
			button1.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					showFlag = false; // Hide 버튼을 누를 시 Flag을 False로 설정
					MyPanel.this.repaint(); 
					// repaint()는 다시 paintComponent()가 호출되게 하여, 
					// showFlag가 true이면 그리고 false이면 그리지 않도록 함
				}				
			});
			button2.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					showFlag = true; // Show 버튼을 누를 시 Flag을 True로 설정
					MyPanel.this.repaint();
				}
			});
		}
		
		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			if(showFlag) // true이면 그리고 false이면 그리지 않음
				g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this);			
		}
	}
	
	static public void main(String[] args) {
		new ImageDrawPracticeFrame2Ex();
	}
}
