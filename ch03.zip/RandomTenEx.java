package ch03;


public class RandomTenEx {

	public static void main(String[] args) {
		int n [] = new int [20]; // 배열 생성
		
		for(int i=0; i<n.length; i++) { // 10개의 랜덤한 정수 생성 및 저장
			int r = (int)(Math.random()*20 + 1);
			n[i] = r;
		}
		
		int sum = 0;
		for(int i=0; i<n.length; i++) // 합 구하기
			sum += n[i];
		
		System.out.print("랜덤한 정수들 : ");
		for(int i=0; i<n.length; i++)
			System.out.print(n[i] +" ");
			System.out.println();
			
		System.out.print("Selection 정렬한 정수들 : ");
		
		for(int i = 0; i < n.length - 1; i++) {
			// 현재 탐색에서 가장 앞의 원소를 초기 값으로 설정해둔다.
			int MinIndex = i;
			// 탐색을 진행하며, 가장 작은 값을 찾는다.
			for(int j = i + 1; j < n.length; j++) {
				if(n[MinIndex] > n[j])
					MinIndex = j;
			}
			// 탐색이 완료되면 가장 작은 값을 가장 앞의 원소와 가장 작은 원소의 위치를 바꾸어준다.
			int temp = n[MinIndex];
			n[MinIndex] = n[i];
			n[i] = temp;
			System.out.print(n[i] +" ");
		}
		System.out.println();
		
		  int min = n[0];
		  int max = n[0];
		  for (int i = 0; i < n.length; i++) {
		     if (n[i] < min) {
		       min = n[i];
		   }
		 }
		  System.out.println("최소값은 " + min);

		//최대값을 구하라
		  for (int i = 0; i < n.length; i++) {
		       if (n[i] > max) {
		          max = n[i];
		  }
		 }
		System.out.println("최대값은 " + max);

		System.out.print("평균은 " + sum/20);
		  }
	}
