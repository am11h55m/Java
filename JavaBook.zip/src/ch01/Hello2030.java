package ch01;


public class Hello2030 {
	public static void main(String[] args) {
		int n = 2030;
		System.out.println("헬로"+n);
	}
}
