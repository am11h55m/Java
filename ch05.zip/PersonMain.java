package ch05;

class Person {

	private String name;
	private String personNumber;

	public Person(String name, String personNumber) {
		this.name = name;
		this.personNumber = personNumber;
	}

	public void sayHello() {
		System.out.println("안녕하세요. 저는 " + this.name + "입니다. 주민등록번호는 " + personNumber + " 입니다.");
	}
}

class Male extends Person {

	public Male(String name, String personNumber) {
		super(name, personNumber);
	}

	@Override
	public void sayHello() {
		super.sayHello();
		System.out.println("나는 남자입니다.");
	}

}

class Female extends Person {

	public Female(String name, String personNumber) {
		super(name, personNumber);
	}

	@Override
	public void sayHello() {
		super.sayHello();
		System.out.println("나는 여자입니다.");
	}
	
}

public class PersonMain {

	public static void main(String[] args) {
		
		Person person1 = new Male("손흥민", "123456-1234567");
		Person person2 = new Female("박나래", "000000-2222222");
		
		person1.sayHello();
		
		System.out.println("====================================================");
		
		person2.sayHello();

	}

}
