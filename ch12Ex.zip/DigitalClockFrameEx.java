package DigitalClock;

import java.awt.*;
import java.util.Calendar;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class DigitalClockFrame extends JFrame {
	public DigitalClockFrame() {
		setTitle("디지탈 시계 만들기");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.add(new MyLabel1(), BorderLayout.NORTH); // 컨텐트팬의 CENTER에 붙임
		c.add(new MyLabel2(), BorderLayout.SOUTH);
		setSize(400,200);
		setVisible(true);
	}

	class MyLabel1 extends JLabel implements Runnable {
		private Thread timerThread = null;
		public MyLabel1() {
			setText(makeClockText());
			setHorizontalAlignment(JLabel.CENTER);
			setFont(new Font("TimesRoman", Font.ITALIC, 50));
			timerThread = new Thread(MyLabel1.this);
			timerThread.start();
		}
		
		public String makeClockText() {
			Calendar c = Calendar.getInstance();			
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int min = c.get(Calendar.MINUTE);
			int second = c.get(Calendar.SECOND);
			String clockText = "";


			if (hour < 10){
				clockText = clockText.concat("0");
				clockText = clockText.concat(Integer.toString(hour));
				clockText = clockText.concat(":");
			} else{
				clockText = clockText.concat(Integer.toString(hour));
				clockText = clockText.concat(":");
			}
			if (min < 10){
				clockText = clockText.concat("0");
				clockText = clockText.concat(Integer.toString(min));
				clockText = clockText.concat(":");
			} else{
				clockText = clockText.concat(Integer.toString(min));
				clockText = clockText.concat(":");
			}
			if (second < 10){
				clockText = clockText.concat("0");
				clockText = clockText.concat(Integer.toString(second));
			} else{
				clockText = clockText.concat(Integer.toString(second));
			}

			return clockText;
		}
		@Override
		public void run() {
			while(true) {
				try {
					Thread.sleep(1000);
				}
				catch(InterruptedException e){return;}
				setText(makeClockText());
			}
		}
	}
	class MyLabel2 extends JLabel{
		public MyLabel2(){
			setText(makeDateText());
			setHorizontalAlignment(JLabel.CENTER);
			setFont(new Font("TimesRoman", Font.ITALIC, 50));
		}
		public String makeDateText(){
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DATE);

			String dateText = Integer.toString(year);
			dateText = dateText.concat("년");
			dateText = dateText.concat(Integer.toString(month));
			dateText = dateText.concat("월");
			dateText = dateText.concat(Integer.toString(day));
			dateText = dateText.concat("일");

			return dateText;
		}

	}
	public static void main(String [] args) {
		new DigitalClockFrame();
	}
} 
