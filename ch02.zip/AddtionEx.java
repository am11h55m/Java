package ch02;

import java.util.Scanner;

public class AddtionEx {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("두 정수를 입력하세요>>");
		int a = scanner.nextInt();
		int b = scanner.nextInt();
		int sum = a+b;
		int a1 = a-b;
		int b1 = a*b;
		double c1 = (double)a/(double)b;
		System.out.println(a+"+"+b+"은 "+sum);
		System.out.println(a+"-"+b+"은 "+a1);
		System.out.println(a+"*"+b+"은 "+b1);
		System.out.println(a+"/"+b+"은 "+c1);
//		scanner.close();
	}

}
