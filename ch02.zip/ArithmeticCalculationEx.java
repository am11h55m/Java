package ch02;

import java.util.Scanner;

public class ArithmeticCalculationEx {
	
	double x1, x2;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("이차방정식(ax^2+bx+c=0꼴)의 근을 구해주는 프로그램입니다.");
		System.out.print("이차항 계수(a)를 입력하세요");
		double a = scanner.nextInt();
		System.out.print("이차항 계수(b)를 입력하세요");
		double b = scanner.nextInt();
		System.out.print("상수항(c)를 입력하세요");
		double c = scanner.nextInt();
		double determinant = (b*b) - (4*a*c);
		double root = Math.sqrt(determinant);
		
		if(determinant > 0) {
			x1 = (-b+root)/(2*a);
			x2 = (-b-root)/(2*a);
			
		}
		
	//	scanner.close();
	}

}
