package ch08;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyBorderLayoutFrame extends JFrame {
	public MyBorderLayoutFrame() {
		super("BorderLayout Practice"); // setTitle("BorderLayout Practice")와 동일
	//	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout(50, 5));
		c.add(new JButton("East"), BorderLayout.EAST);
		c.add(new JButton("West"), BorderLayout.WEST);
		c.add(new JButton("North"), BorderLayout.NORTH);
		c.add(new JButton("South"), BorderLayout.SOUTH);
		c.add(new JButton("Center"), BorderLayout.CENTER);
		setSize(400,200);
		setVisible(true);
	}
	public static void main(String[] args) {
		new MyBorderLayoutFrame();
	}
}
